import Foundation

func solution(_ n:Int, _ edge:[[Int]]) -> Int {
    let answerArr = BFS(n, edge)
    var cnt = 0
    
    for i in 1...n {
        if answerArr[i] == answerArr[0] {
            cnt += 1
        }
    }
    return cnt
}

func BFS(_ n:Int, _ edge:[[Int]]) -> [Int] {
    var queue:[Int] = [1]
    var visitQueue:[Int] = Array.init(repeating: 50001, count: n + 1)
    var cnt = 0
    var beforeAdd = 1
    var tmpAdd = 0
    
    visitQueue[1] = 0
    
    while !queue.isEmpty {
        let Q = queue.removeFirst()
        beforeAdd -= 1
        
        for E in edge {
            if E[0] == Q || E[1] == Q {
                let np:Int
                if E[0] == Q { np = E[1] }
                else { np = E[0] }
                
                if cnt + 1 < visitQueue[np] {
                    visitQueue[np] = cnt + 1
                    queue.append(np)
                    tmpAdd += 1
                }
            }
        }
        if beforeAdd == 0 && tmpAdd > 0 {
            cnt += 1
            beforeAdd += tmpAdd
            tmpAdd = 0
        }
    }
    visitQueue[0] = cnt
    
    return visitQueue
}

solution(6, [[3, 6], [4, 3], [3, 2], [1, 3], [1, 2], [2, 4], [5, 2]])
