import Foundation

func solution(_ scores:[[Int]]) -> String {
    let sCnt = scores.count
    var answer = ""
    
    for x in 0..<sCnt {
        var startIdx = 1
        var min = scores[0][x]
        var max = scores[0][x]
        var sum = scores[0][x]
        var avr = Double()
        
        if x == 0 {
            min = scores[1][x]
            max = scores[1][x]
            sum = scores[1][x]
            startIdx = 2
        }
        
        for y in startIdx..<sCnt {
            guard x != y else { continue }
            let idx = scores[y][x]
            
            if min >= idx {
                min = idx
            } else if max <= idx {
                max = idx
            }
            sum += idx
        }
        
        if scores[x][x] >= min && scores[x][x] <= max {
            sum += scores[x][x]
            avr = Double(sum) / Double(sCnt)
        } else {
            avr = Double(sum) / Double(sCnt - 1)
        }
        
        switch avr {
            case 90...:
                answer += "A"
            case 80...:
                answer += "B"
            case 70...:
                answer += "C"
            case 50...:
                answer += "D"
            default:
                answer += "F"
        }
    }
    
    return answer
}


solution([[100,90,98,88,65],[50,45,99,85,77],[47,88,95,80,67],[61,57,100,80,65],[24,90,94,75,65]])
