//: [Previous](@previous)

import Foundation

struct Queue<T> {
    private var list:[T] = []
    var isEmpty: Bool {
        return list.isEmpty
    }
    
    mutating func enqueue(_ value: T) {
        list.append(value)
    }
    mutating func dequeue() -> T? {
        guard !isEmpty else { return nil }
        return list.removeFirst()
    }
}

class Node<T> {
    let value: T
    var edges:[Edge<T>] = []
    var visitCnt = 9999999
    
    init(value: T) {
        self.value = value
    }
    
    func appendEdgeTo(_ node: Node<T>) {
        let edge = Edge<T>(from: self, to: node)
        edges.append(edge)
    }
}

class Edge<T> {
    weak var source: Node<T>?
    let destination: Node<T>
    
    init(from source: Node<T>, to destination: Node<T>) {
        self.source = source
        self.destination = destination
    }
}

func BFS(_ N:Int, _ road:[[Int]], _ K:Int) {
    let node = (1...N).map({ Node<Int>(value: $0) })
    for r in road {
        node[r[0] - 1].appendEdgeTo(node[r[1] - 1])
        node[r[1] - 1].appendEdgeTo(node[r[0] - 1])
    }
    
    var queue = Queue<Node<Int>>()
    queue.enqueue(node[0])
    
    while let node = queue.dequeue() {
        for edge in node.edges {
            let dest = edge.destination
            
        }
    }
}

//: [Next](@next)
