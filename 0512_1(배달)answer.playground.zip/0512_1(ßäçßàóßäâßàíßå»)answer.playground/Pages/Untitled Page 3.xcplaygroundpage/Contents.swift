import Foundation

func solution(_ N:Int, _ road:[[Int]], _ k:Int) -> Int {
    return Set(BFS(N, road, k)).count
}

func BFS(_ N:Int, _ road:[[Int]], _ k:Int) -> [Int] {
    let rCnt = road.count
    
    var queue:[Int] = [1]
    var queueCnt:[Int] = Array.init(repeating: 99999999, count: N+1)
    var ansArr:[Int] = [1]
    
    queueCnt[1] = 0
    
    while !queue.isEmpty {
        let Q = queue.removeFirst()
        for i in 0..<rCnt {
            if Q == road[i][0] || Q == road[i][1] {
                let np:Int
                if Q == road[i][0] { np = road[i][1] }
                else { np = road[i][0] }
                
                let cnt = road[i][2] + queueCnt[Q]
                if cnt < queueCnt[np] && cnt <= k {
                    queueCnt[np] = cnt
                    queue.append(np)
                    ansArr.append(np)
                }
            }
        }
    }
    
    return ansArr
}

solution(5, [[1,2,1],[2,3,3],[5,2,2],[1,4,2],[5,3,1],[5,4,2]], 3)
