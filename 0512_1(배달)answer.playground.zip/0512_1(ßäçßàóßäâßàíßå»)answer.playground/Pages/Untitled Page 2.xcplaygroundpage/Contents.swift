import Foundation

var arr:[Int] = [1]

func solution(_ N:Int, _ road:[[Int]], _ k:Int) -> Int {
    var visit:[Int] = Array.init(repeating: 99999999, count: N)
    visit[0] = 0
    
    search(1, 0, road, visit, k)

    return Set(arr).count
}

func search(_ Npos:Int, _ kCnt:Int, _ road:[[Int]], _ visit:[Int], _ k:Int) {
    print(Npos,kCnt)
    
    for r in road {
        if r[0] == Npos || r[1] == Npos{
            if r[2] + kCnt <= k {
                let np:Int
                if r[0] == Npos { np = r[1] }
                else { np = r[0] }
                
                guard visit[np - 1] > kCnt + r[2] else { continue }
                var tmpV = visit
                tmpV[np - 1] = kCnt + r[2]
                
                search(np, kCnt + r[2], road, tmpV, k)
                arr.append(np)
            }
        }
    }
}
 
solution(5, [[1,2,1],[2,3,3],[5,2,2],[1,4,2],[5,3,1],[5,4,2]], 3)
