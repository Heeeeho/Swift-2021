import Foundation

var setArr:Set<Int> = [1]

func solution(_ N:Int, _ road:[[Int]], _ k:Int) -> Int {
    var duplicateCheckArr:[Bool]
    duplicateCheckArr = Array.init(repeating: false, count: road.count)
    
    search(1, 0, road, duplicateCheckArr, k)

    return setArr.count
}

func search(_ Npos:Int, _ kCnt:Int, _ road:[[Int]], _ dpcA:[Bool], _ k:Int) {
    var cnt = -1
    print(Npos,kCnt)
    
    for r in road {
        cnt += 1
        if dpcA[cnt] { continue }
        if r[0] == Npos || r[1] == Npos{
            if r[2] + kCnt <= k {
                let np:Int
                if r[0] == Npos { np = r[1] }
                else { np = r[0] }

                var dpA = dpcA
                dpA[cnt] = true

                search(np, kCnt + r[2], road, dpA, k)
                setArr.insert(np)
                dpA[cnt] = false
            }
        }
    }
}
 
solution(5, [[1,2,1],[2,3,3],[5,2,2],[1,4,2],[5,3,1],[5,4,2]], 3)
