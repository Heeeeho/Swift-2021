import Foundation

func solution(_ s:[String]) -> [String] {
    var answer:[String] = []
    
    for str in s {
        var stack:[Character] = []
        var oneCnt = 0
        var threeOneIdx = -1
        var idx = 0
        
        for ch in str {
            var flag:Bool = true
            if ch == "1" {
                oneCnt += 1
                if oneCnt == 3 {
                    threeOneIdx = idx
                }
            } else if ch == "0" && oneCnt >= 2 && threeOneIdx >= 0{
                flag = false
                let arr = inputZero(idx, threeOneIdx, &stack)
                oneCnt = arr[0]
                threeOneIdx = arr[1]
            } else if ch == "0" {
                oneCnt = 0
            }
            if flag { stack.append(ch) }
            idx += 1
        }
        answer.append(stack.map{String($0)}.reduce("", +))
    }
    
    return answer
}

func inputZero(_ idx:Int, _ tIdx:Int, _ stack:inout[Character]) -> [Int] {
    var rmArr:[Character] = []
    var oneCnt = 0
    var threeOneIdx = -1
    
    for _ in tIdx..<idx {
        let rm = stack.removeLast()
        rmArr.append(rm)
    }
    stack.append("0")
    
    var tmpIdx = tIdx + 1
    for rm in rmArr.reversed() {
        if rm == "1" {
            oneCnt += 1
            if oneCnt == 3 {
                threeOneIdx = tmpIdx
            }
        } else {
            oneCnt = 0
        }
        stack.append(rm)
        tmpIdx += 1
    }
    
    return [oneCnt, threeOneIdx]
}

solution(["100111100"])
