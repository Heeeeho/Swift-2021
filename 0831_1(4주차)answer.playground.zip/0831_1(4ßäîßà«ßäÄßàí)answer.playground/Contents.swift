import Foundation

func solution(_ table:[String], _ languages:[String], _ preference:[Int]) -> String {
    
    var answer = [String]()
    var max = -1
    
    for str in table {
        var blankCnt = 0
        var work = ""
        var languageArr:[String] = ["","","","",""]
        
        for ch in str {
            if ch == " " {
                blankCnt += 1
                continue
            }
            if blankCnt == 0 {
               work += String(ch)
            } else {
                languageArr[blankCnt - 1] += String(ch)
            }
        }
        
        var tmp = 0
        for i in 0..<5 {
            var cnt = 0
            for lan in languages {
                if languageArr[i] == lan {
                    tmp = tmp + (5-i)*preference[cnt]
                }
                cnt += 1
            }
        }
        
        if max == -1 || tmp >= max{
            if tmp == max || max == -1 {
                answer.append(work)
            } else {
                answer.removeAll()
                answer.append(work)
            }
            max = tmp
        }
    }
    
    return answer.sorted(by: {(s1:String,s2:String) -> Bool in
        return s1 < s2
    }).first!
}


solution(["SI JAVA JAVASCRIPT SQL PYTHON C#", "CONTENTS JAVASCRIPT JAVA PYTHON SQL C++", "HARDWARE C C++ PYTHON JAVA JAVASCRIPT", "PORTAL JAVA JAVASCRIPT PYTHON KOTLIN PHP", "GAME C++ C# JAVASCRIPT C JAVA"], ["JAVA", "JAVASCRIPT"], [7, 5])
