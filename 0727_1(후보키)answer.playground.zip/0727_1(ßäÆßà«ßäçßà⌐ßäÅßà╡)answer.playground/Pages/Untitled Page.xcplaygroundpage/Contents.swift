import Foundation

var rowCnt:Int = 0      // y
var columnCnt:Int = 0   // x
var mixKey:[String] = []
var answer:Int = 0

func solution(_ relation:[[String]]) -> Int {
    rowCnt = relation.count
    columnCnt = relation[0].count
    
    var columnBool:[Bool] = Array.init(repeating: false, count: columnCnt)
    
    for i in 0..<columnCnt {
        var setArr:Set<String> = []
        
        for j in 0..<rowCnt {
            setArr.insert(relation[j][i])
        }
        
        if setArr.count == rowCnt {
            answer += 1
            columnBool[i] = true
        }
    }
    
    for i in 0..<columnCnt {
        guard !columnBool[i] else { continue }

        var strArr:[String] = []

        for j in 0..<rowCnt {
            strArr.append(relation[j][i])
        }
        
        mixColumn(i, strArr,"\(i)", columnBool, relation)
    }
    
    
    return answer + minimality()
}

func mixColumn(_ idx:Int, _ strArr:[String], _ intArr:String, _ columnBool:[Bool], _ relation:[[String]]) {
    guard idx + 1 < columnCnt else { return }

    for i in idx+1..<columnCnt {
        guard !columnBool[i] else { continue }
        
        var tmpStrArr = strArr
        let tmpIntArr = intArr + "\(i)"

        for j in 0..<rowCnt {
            tmpStrArr[j] += relation[j][i]
        }

        if Set(tmpStrArr).count == rowCnt { // 후보키 완성
            mixKey.append(tmpIntArr)
        } else {
            mixColumn(i, tmpStrArr, tmpIntArr, columnBool, relation)
        }
    }
}

func minimality() -> Int{
    let mCnt = mixKey.count
    var minus = 0
    var minusArr:[Bool] = Array.init(repeating: false, count: mCnt)
    
    mixKey = mixKey.sorted(by: {(s1: String, s2: String) -> Bool in
        return s1.count < s2.count
    })
    
    for i in 0..<mCnt {
        let s1Cnt = mixKey[i].count
        
        for j in i+1..<mCnt {
            guard !minusArr[j] else { continue }
            var cnt:Int = 0
            
            for s2 in mixKey[j] {
                if s2 == Array(mixKey[i])[cnt] { cnt += 1 }
                if cnt == s1Cnt {
                    minus += 1
                    minusArr[j] = true
                    break
                }
            }
        }
    }
    
    return mCnt - minus
}


solution([["100","ryan","music","2"],
          ["200","apeach","math","2"],
          ["300","tube","computer","3"],
          ["400","con","computer","4"],
          ["500","ryan","math","2"],
          ["600","apeach","math","1"]])

