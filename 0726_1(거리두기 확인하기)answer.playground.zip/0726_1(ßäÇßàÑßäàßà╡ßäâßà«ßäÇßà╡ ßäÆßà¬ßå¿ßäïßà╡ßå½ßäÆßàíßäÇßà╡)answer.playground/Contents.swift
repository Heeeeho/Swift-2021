import Foundation

func solution(_ places:[[String]]) -> [Int] {
    var answer:[Int] = []
    
    
    for place in places {
        var pArr:[[Int]] = []
        
        for idx in 0..<5 {  // P 좌표 추출
            var cnt = 0
            for i in place[idx] {
                if i == "P" {
                    pArr.append([idx,cnt]) // y x
                }
                cnt += 1
            }
        }
        
        let pcnt = pArr.count
        var key = true
        
        for p0 in 0..<pcnt {
            for p1 in p0+1..<pcnt {
                let ydis = abs(pArr[p0][0] - pArr[p1][0])
                let xdis = abs(pArr[p0][1] - pArr[p1][1])
                let distance = xdis + ydis
                
                
                
                if distance > 2 {
                    continue
                } else if distance == 1 {
                    key = false
                } else if distance <= 2 {
                    if xdis == 0 && ydis == 2 {
                        if Array(place[pArr[p0][0] + 1])[pArr[p0][1]] == "O" {
                            key = false
                        }
                    } else if xdis == 2 && ydis == 0 {
                        if Array(place[pArr[p0][0]])[pArr[p0][1] + 1] == "O" {
                            key = false
                        }
                    } else {
                        if pArr[p0][1] < pArr[p1][1] {
                            if Array(place[pArr[p0][0] + 1])[pArr[p0][1]] == "O" {
                                key = false
                            }
                            if Array(place[pArr[p0][0]])[pArr[p0][1] + 1] == "O" {
                                key = false
                            }
                        } else {
                            if Array(place[pArr[p0][0] + 1])[pArr[p0][1]] == "O" {
                                key = false
                            }
                            if Array(place[pArr[p0][0]])[pArr[p0][1] - 1] == "O" {
                                key = false
                            }
                        }
                    }
                }
                
                if key == false {
                    answer.append(0)
                    break
                }
            }
            if key == false { break }
        }
        if key == true { answer.append(1) }
    }
    
    return answer
}


solution([["POOOP", "OXXOX", "OPXPX", "OOXOX", "POXXP"], ["POOPX", "OXPXP", "PXXXO", "OXXXO", "OOOPP"], ["PXOPX", "OXOXP", "OXPOX", "OXXOP", "PXPOX"], ["OOOXX", "XOOOX", "OOOXX", "OXOOX", "OOOOO"], ["PXPXP", "XPXPX", "PXPXP", "XPXPX", "PXPXP"]])
