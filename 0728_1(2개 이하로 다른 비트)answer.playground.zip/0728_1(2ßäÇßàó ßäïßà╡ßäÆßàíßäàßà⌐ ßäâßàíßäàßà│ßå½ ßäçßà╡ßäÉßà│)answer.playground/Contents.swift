import Foundation

func solution(_ numbers:[Int64]) -> [Int64] {
    var answer:[Int64] = []

    for idx in numbers {
        let tmp = idx%2 == 0 ? idx + 1 : idx + (idx ^ (idx + 1) + 1) / 4
        
        answer.append(tmp)
    }
    return answer
}
