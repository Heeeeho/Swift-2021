import Foundation

var nCnt:Int = 0
var setArr:Set<Int> = []
var max:Int = 0

func fullSearsh(_ idx:Int, _ n:String, _ mkNum:String) {
    var jump:Int = 0
    
    while true {
        let tmp = Int(mkNum)!
        
        if tmp > max { max = tmp }
        setArr.insert(tmp)
        
        jump += 1
        let np = jump + idx
        
        if np >= nCnt { break }
        
        if np - idx > 1 {
            var adds:String = ""
            var s:String = ""
            var cnt = 0
            
            for i in 0..<nCnt {
                if idx < i && np > i {
                    adds += String(Array(n)[i])
                    cnt += 1
                } else {
                    s += String(Array(n)[i])
                }
            }
            
            s += adds
            
            fullSearsh(np - cnt, s, mkNum + String(Array(n)[np]))
        } else {
            fullSearsh(np, n, mkNum + String(Array(n)[np]))
        }
    }
}


func solution(_ numbers:String) -> Int {
    var numbers = numbers
    nCnt = numbers.count
    
    for _ in 0..<nCnt {
        fullSearsh(0, numbers, String(Array(numbers)[0]))
        let tmp = numbers.remove(at: numbers.startIndex)
        numbers.append(tmp)
    }
    
    var bool:[Bool] = Array.init(repeating: true, count: max+1)
    bool[0] = false
    bool[1] = false
    
    for i in 2...max {
        if bool[i] == false { continue }
        for j in stride(from: i*i, to: max+1, by: i) {
            bool[j] = false
        }
    }
    
    var answer = 0
    for i in 0..<setArr.count {
        if bool[Array(setArr)[i]] == true {
            answer += 1
        }
    }
    
    return answer
}

solution("17")
