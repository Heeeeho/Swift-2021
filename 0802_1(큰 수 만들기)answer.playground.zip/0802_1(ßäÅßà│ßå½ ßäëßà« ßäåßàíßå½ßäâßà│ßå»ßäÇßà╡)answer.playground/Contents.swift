import Foundation

func solution(_ number:String, _ k:Int) -> String {
    let lenN = number.count
    let lenA = number.count - k
    let num = number.map{Character(String($0))}
    
    var key = -1
    var answer:[Character] = []
    
    for _ in 0..<lenA {
        var tmp:Character = "0"
        
        for idx in key+1..<lenN-(lenA - answer.count)+1 {
            if tmp < num[idx] {
                key = idx
                tmp = num[idx]
                if tmp == "9" { break }
            }
        }
        answer.append(tmp)
    }
    
    return answer.map{String($0)}.reduce("", +)
}


solution("4177252841", 4)
