//: [Previous](@previous)

import Foundation

func solution(_ s:String) -> Int {
    let sCnt = s.count
    let sDic:[Character:Character] = ["[":"]","{":"}","(":")"]
    var answer = 0
    
    for rotateIdx in 0..<sCnt {
        var flag = true
        var braketArr:[Character] = []
        var top = -1
        
        func Braketstack(_ num:Int) -> Bool{
            let tmpIdx = Array(s)[num]
            
            if tmpIdx == "[" || tmpIdx == "(" || tmpIdx == "{" {
                braketArr.append(tmpIdx)
                top += 1
            } else {
                if top == -1 { return false }
                
                if sDic[braketArr[top]] == tmpIdx {
                    braketArr.removeLast()
                    top -= 1
                } else {
                    return false
                }
            }
            return true
        }
        
        for i in rotateIdx..<sCnt {
            flag = Braketstack(i)
            if !flag { break }
        }
        if flag {
            for i in 0..<rotateIdx {
                flag = Braketstack(i)
                if !flag { break }
            }
            if flag {
                if braketArr.isEmpty {
                    answer += 1
                }
            }
        }
    }
    
    return answer
}

solution("[](){}")

//: [Next](@next)
