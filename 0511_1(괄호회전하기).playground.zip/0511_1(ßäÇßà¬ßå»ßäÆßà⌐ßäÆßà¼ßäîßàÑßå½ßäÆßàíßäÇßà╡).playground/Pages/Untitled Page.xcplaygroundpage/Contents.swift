import Foundation

func solution(_ s:String) -> Int {
    let sCnt = s.count
    let braketDic:[Character:[Int]] = ["[":[0,1],"]":[0,-1],"(":[1,1],")":[1,-1],"{":[2,1],"}":[2,-1]]
    var answer = 0
    
    for rotateIdx in 0..<sCnt {
        var flag = true
        var braketArr:[Character] = []
        var top = -1
        
        func Braketstack(_ num:Int) -> Bool{
            let tmpIdx = Array(s)[num]
            
            if braketDic[tmpIdx]![1] == 1 {
                braketArr.append(tmpIdx)
                top += 1
            } else {
                if braketArr.isEmpty { return false }
                if braketDic[braketArr[top]]![0] == braketDic[tmpIdx]![0] {
                    braketArr.removeLast()
                    top -= 1
                } else {
                    return false
                }
            }
            return true
        }
        
        for i in rotateIdx..<sCnt {
            flag = Braketstack(i)
            if !flag { break }
        }
        if flag {
            for i in 0..<rotateIdx {
                flag = Braketstack(i)
                if !flag { break }
            }
            if flag {
                if braketArr.isEmpty {
                    answer += 1
                }
            }
        }
    }
    
    return answer
}

solution("[(])")



