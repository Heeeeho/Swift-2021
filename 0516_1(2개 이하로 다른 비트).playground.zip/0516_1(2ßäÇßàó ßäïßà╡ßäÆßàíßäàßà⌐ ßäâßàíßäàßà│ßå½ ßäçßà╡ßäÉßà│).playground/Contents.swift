import Foundation

func solution(_ numbers:[Int64]) -> [Int64] {
    var answer:[Int64] = []
    for N in numbers {
        let radix2 = String(N, radix: 2)
        
        if radix2.last == "0" {
            answer.append(N+1)
        } else if Array(radix2)[radix2.count - 1] == "0" {
            answer.append(N+2)
        }
    }
    
    return []
}

solution([7])
