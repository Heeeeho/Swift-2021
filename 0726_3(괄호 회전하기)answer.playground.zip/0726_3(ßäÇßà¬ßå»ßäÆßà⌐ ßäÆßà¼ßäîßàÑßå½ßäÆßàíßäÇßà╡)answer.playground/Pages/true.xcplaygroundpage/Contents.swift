//: [Previous](@previous)

import Foundation

func solution(_ s:String) -> Int {
    let scnt = s.count
    var s = s
    var answer = 0
    
    let dic:[String:Int] = ["[":0,"{":1,"(":2,"]":3,"}":4,")":5]

    
    for _ in 0..<scnt {
        var stack:[String] = []
        var key = true
        
        for idx in s {
            let tmp = String(idx)
            if dic[tmp]! < 3 {
                stack.append(tmp)
            } else {
                guard !stack.isEmpty else {
                    key = false
                    break
                }
                if dic[stack.last!]!+3 == dic[tmp]! {
                    stack.removeLast()
                } else {
                    key = false
                    break
                }
            }
        }
        if key == true {
            if stack.isEmpty {
                answer += 1
            }
        }
        
        s = rotate(s: &s)
    }
    
    return answer
}

func rotate(s:inout String) -> String {
    let first = s.removeFirst()
    s += String(first)
    return s
}


//: [Next](@next)


// 4099 2054 1961
