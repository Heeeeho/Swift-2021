import Foundation

func solution(_ s:String) -> Int {
    let scnt = s.count
    var s = s
    var answer = 0

    for i in 0..<scnt {
        var stack:[Character] = []
        var key = true
        
        for idx in i..<i + scnt {
            let tmp = Array(s)[idx]
            
            if tmp == "[" || tmp == "{" || tmp == "(" {
                stack.append(tmp)
            } else {
                guard !stack.isEmpty else {
                    key = false
                    break
                }
                let last = stack.removeLast()
                
                if last == "[" && tmp == "]" { continue }
                else if last == "{" && tmp == "}" { continue }
                else if last == "(" && tmp == ")" { continue }
                else {
                    key = false
                    break
                }
            }
        }
        if key == true {
            if stack.isEmpty {
                answer += 1
            }
        }
        
        s += String(Array(s)[i])
    }
    
    return answer
}

solution("[](){}")
