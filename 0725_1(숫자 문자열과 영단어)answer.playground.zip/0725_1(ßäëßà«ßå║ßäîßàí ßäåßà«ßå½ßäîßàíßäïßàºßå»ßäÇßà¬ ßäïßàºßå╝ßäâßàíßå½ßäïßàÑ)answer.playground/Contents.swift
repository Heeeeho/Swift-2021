import Foundation

func solution(_ s:String) -> Int {
    var idx:Int = 0
    var result:String = ""
    
    let dic:[String:[Int]] = ["ze":[0,4],"on":[1,3],"tw":[2,3],"th":[3,5],"fo":[4,4],"fi":[5,4],
                              "si":[6,3],"se":[7,5],"ei":[8,5],"ni":[9,4]]
    
    while idx < s.count {
        if Int(String(Array(s)[idx])) == nil {
            let dicValue = dic[String(Array(s)[idx])+String(Array(s)[idx+1])]
            result += String(dicValue![0])
            idx += dicValue![1]
        } else {
            result += String(Array(s)[idx])
            idx += 1
        }
    }
    
    return Int(result)!
}

solution("123")
