import Foundation

func solution(_ price:Int, _ money:Int, _ count:Int) -> Int64{
    let tmp = (1...count).map({(idx:Int) -> Int64 in
        return Int64(idx * price)
    }).reduce(0, +) - Int64(money)
    
    return tmp>0 ? tmp:0
}

solution(3, 20, 4)
