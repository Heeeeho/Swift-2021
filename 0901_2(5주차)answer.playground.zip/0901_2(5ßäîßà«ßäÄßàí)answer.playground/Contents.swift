import Foundation

func solution(_ word:String) -> Int {
    let word = word.map{$0}
    
    let arr:[Character] = ["A","E","I","O","U"]
    var arrCnt = [0,0,0,0,0,0]
    var str:[Character] = []
    var total = 0
    var cnt = 1
    
    while true {
        if cnt <= 5 && str.count < 5 && arrCnt[cnt] != 5{
            str.append(arr[arrCnt[cnt]])
            arrCnt[cnt] += 1
            if cnt < 5 { cnt += 1 }
        } else if arrCnt[cnt] < 5{
            str[cnt - 1] = arr[arrCnt[cnt]]
            arrCnt[cnt] += 1
        } else if arrCnt[cnt] == 5 {
            str.removeLast()
            arrCnt[cnt] = 0
            cnt -= 1
            
            if arrCnt[cnt] < 5 {
                str[cnt - 1] = arr[arrCnt[cnt]]
                arrCnt[cnt] += 1
                cnt += 1
            } else {
                continue
            }
        }
        total += 1

        if word == str {
            break
        }
    }
    
    return total
}

solution("UUUUU")
