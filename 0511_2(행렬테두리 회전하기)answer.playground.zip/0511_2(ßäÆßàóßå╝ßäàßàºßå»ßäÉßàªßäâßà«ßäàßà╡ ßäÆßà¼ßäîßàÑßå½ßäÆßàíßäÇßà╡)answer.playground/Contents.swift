import Foundation

func solution(_ rows:Int, _ columns:Int, _ queries:[[Int]]) -> [Int] {
    var arr = Array(repeating: Array(repeating: 1, count: columns), count: rows)
    var answer:[Int] = []
    
    var cnt = 0
    for i in 0..<rows {
        for j in 0..<columns {
            cnt += 1
            arr[i][j] = cnt
        }
    }
    
    for i in 0..<queries.count {
        let y1 = queries[i][0] - 1
        let x1 = queries[i][1] - 1
        let y2 = queries[i][2] - 1
        let x2 = queries[i][3] - 1
        
        var back = 0
        var min = 10000
        func swap(_ y:Int,_ x:Int,_ back:Int) -> Int {
            var next = 0
            if back < min { min = back }
            next = arr[y][x]
            arr[y][x] = back
            return next
        }
        
        for right in x1..<x2 {
            if right == x1 {
                back = arr[y1][right]
                arr[y1][right] = arr[y1+1][right]
                min = arr[y1][right]
            }
            back = swap(y1, right+1, back)
        }
        for down in y1..<y2-1 {
            back = swap(down+1, x2, back)
        }
        for left in (x1..<x2).reversed() {
            back = swap(y2, left+1, back)
        }
        for up in (y1..<y2).reversed() {
            back = swap(up+1, x1, back)
        }
        for i in 0..<rows {
            print(arr[i])
        }
        answer.append(min)
    }
    
    return answer
}


solution(6, 6, [[1,1,6,2]])
