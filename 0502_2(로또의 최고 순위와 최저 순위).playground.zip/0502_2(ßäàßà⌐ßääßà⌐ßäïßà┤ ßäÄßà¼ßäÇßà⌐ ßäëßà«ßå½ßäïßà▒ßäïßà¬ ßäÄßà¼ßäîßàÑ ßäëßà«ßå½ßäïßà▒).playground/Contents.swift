import Foundation

func solution(_ lottos:[Int], _ win_nums:[Int]) -> [Int] {
    var win_count = 0
    var zero_count = 0
    
    for i in 0..<6 {
        if lottos[i] == 0 {
            zero_count += 1
            continue
        }
        for j in 0..<6 {
            if lottos[i] == win_nums[j] {
                win_count += 1
                break
            }
        }
    }
    
    return [win_count + zero_count == 0 ? 6 : 7 - win_count - zero_count,win_count < 2 ? 6 : 7 - win_count]
}

solution([8, 7, 5, 4, 3, 2], [31, 10, 45, 1, 6, 19])
