import Foundation

var gLineCnt = Int()

func solution(_ game_board:[[Int]], _ table:[[Int]]) -> Int {
    
    gLineCnt = game_board.count
    
    var CPgame_board:[[Int]] = game_board
    var CPtable:[[Int]] = table
    
    var game_board_block:[[[Int]]] = []
    var table_block:[[[Int]]] = []
    
    for y in 0..<gLineCnt {
        for x in 0..<gLineCnt {
            if CPgame_board[y][x] == 0 {
                game_board_block.append(BFS([y,x], &CPgame_board, 0))
            }
            if CPtable[y][x] == 1 {
                table_block.append(BFS([y,x], &CPtable, 1))
            }
        }
    }
    
    return putBlock(game_board_block, table_block)
}

func BFS(_ startIdx:[Int], _ board:inout[[Int]], _ mode:Int) -> [[Int]] {
    let dir = [[0,1],[1,0],[0,-1],[-1,0]] // 동 남 서 북
    
    var blockArr:[[Int]] = [startIdx]
    var queue:[[Int]] = [startIdx] // 처음 빈칸 좌표를 넣는다
    
    board[startIdx[0]][startIdx[1]] = abs(mode - 1)
    
    while !queue.isEmpty {
        let  Q = queue.removeFirst()
        
        for D in dir {
            let dy = Q[0] + D[0]
            let dx = Q[1] + D[1]
            
            guard dy < gLineCnt && dx < gLineCnt else { continue } // 배열 내를 안넘어가는지 체크
            guard dy >= 0 && dx >= 0 else { continue }
            
            if board[dy][dx] == mode {
                queue.append([dy,dx])
                blockArr.append([dy,dx])
                board[dy][dx] = abs(mode - 1)
            }
        }
    }
    
    return blockArr
}

func putBlock(_ gbb:[[[Int]]], _ tb:[[[Int]]]) -> Int {
    var cnt = 0
    var usedBlank:[Bool] = Array.init(repeating: false, count: gbb.count)
    
    for t in 0..<tb.count {
        let tCnt = tb[t].count
        
        for g in 0..<gbb.count {
            guard !usedBlank[g] else { continue }
            if gbb[g].count == tCnt {
                if putBlockCheck(gbb[g], tb[t], tCnt) {
                    print("gm",gbb[g])
                    print("tb",tb[t],"\n")
                    cnt += tCnt
                    usedBlank[g] = true
                    break
                }
            }
        }
    }
    
    print(usedBlank)
    
    return cnt
}

func putBlockCheck(_ gbb:[[Int]], _ tb:[[Int]], _ cnt:Int) -> Bool {
    var tb = tb
    
    for loop in 0..<4 {
        print(tb)
        let yy = gbb[0][0] - tb[0][0]
        let xx = gbb[0][1] - tb[0][1]
        
        var flag = true
        for i in 1..<cnt {
            var tmpFlag = false
            for j in 1..<cnt {
                guard tb[j][0] + yy>=0 && tb[j][1] + xx >= 0 else { continue }
                guard tb[j][0] + yy<gLineCnt && tb[j][1] + xx<gLineCnt else { continue }

                if gbb[i][0] == tb[j][0] + yy && gbb[i][1] == tb[j][1] + xx {
                    tmpFlag = true
                    break
                }
            }
            if !tmpFlag {
                flag = false
                break
            }
        }
        if flag { return true }
        else if loop < 3 {
            var tmpArr:[[Int]] = []
            var min:[Int] = [51,51]
            
            for i in 0..<cnt {
                let tmp = rotate(tb[i][0], tb[i][1])
                if min[0] > tmp[0] {
                    min[0] = tmp[0]
                    min[1] = tmp[1]
                } else if min[0] == tmp[0] {
                    if min[1] > tmp[1] {
                        min[0] = tmp[0]
                        min[1] = tmp[1]
                    }
                }
                tmpArr.append([tmp[0],tmp[1]])
            }
            
            tb[0][0] = min[0]
            tb[0][1] = min[1]
            
            print(tmpArr)
            print(min)
            print("-------")
            
            var idx = 1
            for i in 0..<cnt {
                if tmpArr[i][0] != min[0] {
                    tb[idx][0] = tmpArr[i][0]
                    tb[idx][1] = tmpArr[i][1]
                    idx += 1
                } else if tmpArr[i][1] != min[1]{
                    tb[idx][0] = tmpArr[i][0]
                    tb[idx][1] = tmpArr[i][1]
                    idx += 1
                }
            }
        }
    }
    print("-----------\n")
    return false
}

func rotate(_ y:Int, _ x:Int) -> [Int] {
    return [x, gLineCnt - 1 - y]
}


solution([[1,1,0,0,1,0],[0,0,1,0,1,0],[0,1,1,0,0,1],[1,1,0,1,1,1],[1,0,0,0,1,0],[0,1,1,1,0,0]], [[1,0,0,1,1,0],[1,0,1,0,1,0],[0,1,1,0,1,1],[0,0,1,0,0,0],[1,1,0,1,1,0],[0,1,0,0,0,0]])
